import axios from 'axios';
import { logger } from '../utils/logger';
import { config } from '../config/config';
import { humeAiService } from './hume-ai.service';
import { geminiService } from './gemini.service';

/**
 * Service for mixed emotion-language analysis
 * Combines voice emotion recognition with language processing
 */
class MixedAnalysisService {
  /**
   * Analyze a voice response for both emotional and language content
   * @param {string} audioUrl - URL of the audio file to analyze
   * @param {string} transcription - Text transcription of the audio
   * @returns {Promise<Object>} - Combined analysis results
   */
  async analyzeResponse(audioUrl, transcription) {
    try {
      logger.info(`Starting mixed analysis for response: ${audioUrl}`);
      
      // Run emotion and language analyses in parallel for efficiency
      const [emotionResults, languageResults] = await Promise.all([
        this.getEmotionAnalysis(audioUrl),
        this.getLanguageAnalysis(transcription)
      ]);
      
      // Combine the results with correlation analysis
      const combinedResults = this.correlateResults(emotionResults, languageResults);
      
      logger.info(`Completed mixed analysis for response: ${audioUrl}`);
      return combinedResults;
    } catch (error) {
      logger.error(`Error in mixed analysis: ${error.message}`);
      throw new Error(`Mixed analysis failed: ${error.message}`);
    }
  }
  
  /**
   * Get emotion analysis from Hume AI
   * @param {string} audioUrl - URL of the audio file to analyze
   * @returns {Promise<Object>} - Emotion analysis results
   */
  async getEmotionAnalysis(audioUrl) {
    try {
      // Use the Hume AI service to analyze emotions in the voice recording
      const emotionResults = await humeAiService.analyzeVoiceEmotion(audioUrl);
      return emotionResults;
    } catch (error) {
      logger.error(`Error in emotion analysis: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Get language analysis from Gemini API
   * @param {string} transcription - Text transcription to analyze
   * @returns {Promise<Object>} - Language analysis results
   */
  async getLanguageAnalysis(transcription) {
    try {
      // Use the Gemini service to analyze language sentiment and themes
      const languageResults = await geminiService.analyzeText(transcription);
      return languageResults;
    } catch (error) {
      logger.error(`Error in language analysis: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * Correlate emotion and language results to find patterns and insights
   * @param {Object} emotionResults - Results from emotion analysis
   * @param {Object} languageResults - Results from language analysis
   * @returns {Object} - Correlated analysis with insights
   */
  correlateResults(emotionResults, languageResults) {
    try {
      // Extract primary data from both analyses
      const { emotions, emotionIntensities } = emotionResults;
      const { sentiment, themes } = languageResults;
      
      // Create emotion-language correlation data
      const correlationData = this.createCorrelationData(emotions, sentiment);
      
      // Identify emotional contradictions
      const contradictions = this.identifyContradictions(emotions, sentiment);
      
      // Connect themes with emotions
      const themeEmotionConnections = this.connectThemesWithEmotions(themes, emotions);
      
      // Generate insights based on the combined analysis
      const insights = this.generateInsights(
        emotions, 
        emotionIntensities, 
        sentiment, 
        themes, 
        contradictions
      );
      
      // Create strategic recommendations
      const recommendations = this.createRecommendations(
        contradictions,
        themeEmotionConnections,
        emotionIntensities
      );
      
      return {
        emotionResults,
        languageResults,
        correlationData,
        contradictions,
        themeEmotionConnections,
        insights,
        recommendations
      };
    } catch (error) {
      logger.error(`Error in correlation analysis: ${error.message}`);
      throw new Error(`Correlation analysis failed: ${error.message}`);
    }
  }
  
  /**
   * Create correlation data between emotions and language sentiment
   * @param {Array} emotions - Detected emotions
   * @param {Object} sentiment - Language sentiment analysis
   * @returns {Array} - Correlation data for visualization
   */
  createCorrelationData(emotions, sentiment) {
    // Initialize correlation data structure
    const correlationData = emotions.map(emotion => ({
      emotion: emotion.name,
      positiveLanguage: 0,
      neutralLanguage: 0,
      negativeLanguage: 0
    }));
    
    // Calculate correlation percentages based on emotion and sentiment overlap
    // This is a simplified version - in production, this would use more sophisticated algorithms
    correlationData.forEach(item => {
      const emotion = emotions.find(e => e.name === item.emotion);
      
      // Default distribution based on typical patterns
      if (emotion.name === 'Joy' || emotion.name === 'Surprise') {
        item.positiveLanguage = 70;
        item.neutralLanguage = 20;
        item.negativeLanguage = 10;
      } else if (emotion.name === 'Sadness' || emotion.name === 'Anger' || 
                 emotion.name === 'Fear' || emotion.name === 'Disgust') {
        item.positiveLanguage = 10;
        item.neutralLanguage = 20;
        item.negativeLanguage = 70;
      } else {
        // Neutral emotion
        item.positiveLanguage = 33;
        item.neutralLanguage = 34;
        item.negativeLanguage = 33;
      }
      
      // Adjust based on actual sentiment
      if (sentiment.positive > 0.6) {
        item.positiveLanguage += 15;
        item.negativeLanguage -= 10;
        item.neutralLanguage -= 5;
      } else if (sentiment.negative > 0.6) {
        item.negativeLanguage += 15;
        item.positiveLanguage -= 10;
        item.neutralLanguage -= 5;
      }
      
      // Ensure values are within bounds
      item.positiveLanguage = Math.max(0, Math.min(100, item.positiveLanguage));
      item.neutralLanguage = Math.max(0, Math.min(100, item.neutralLanguage));
      item.negativeLanguage = Math.max(0, Math.min(100, item.negativeLanguage));
      
      // Ensure they sum to 100%
      const total = item.positiveLanguage + item.neutralLanguage + item.negativeLanguage;
      item.positiveLanguage = Math.round((item.positiveLanguage / total) * 100);
      item.neutralLanguage = Math.round((item.neutralLanguage / total) * 100);
      item.negativeLanguage = 100 - item.positiveLanguage - item.neutralLanguage;
    });
    
    return correlationData;
  }
  
  /**
   * Identify contradictions between emotions and language
   * @param {Array} emotions - Detected emotions
   * @param {Object} sentiment - Language sentiment analysis
   * @returns {Array} - List of contradictions
   */
  identifyContradictions(emotions, sentiment) {
    const contradictions = [];
    
    // Define expected sentiment for each emotion
    const expectedSentiment = {
      'Joy': 'positive',
      'Surprise': 'mixed',
      'Sadness': 'negative',
      'Anger': 'negative',
      'Fear': 'negative',
      'Disgust': 'negative',
      'Neutral': 'neutral'
    };
    
    // Determine actual sentiment
    let actualSentiment;
    if (sentiment.positive > sentiment.negative && sentiment.positive > sentiment.neutral) {
      actualSentiment = 'positive';
    } else if (sentiment.negative > sentiment.positive && sentiment.negative > sentiment.neutral) {
      actualSentiment = 'negative';
    } else {
      actualSentiment = 'neutral';
    }
    
    // Check for contradictions
    emotions.forEach(emotion => {
      const expected = expectedSentiment[emotion.name];
      
      // If expected is 'mixed', it's not a contradiction
      if (expected !== 'mixed' && expected !== actualSentiment) {
        contradictions.push({
          emotion: emotion.name,
          intensity: emotion.intensity,
          expectedSentiment: expected,
          actualSentiment: actualSentiment,
          significance: emotion.intensity * Math.abs(sentiment[expected] - sentiment[actualSentiment])
        });
      }
    });
    
    // Sort by significance
    return contradictions.sort((a, b) => b.significance - a.significance);
  }
  
  /**
   * Connect themes with emotions
   * @param {Array} themes - Identified themes
   * @param {Array} emotions - Detected emotions
   * @returns {Array} - Theme-emotion connections
   */
  connectThemesWithEmotions(themes, emotions) {
    // Create connections between themes and emotions
    return themes.map(theme => {
      // Find emotions that occur in the same segments as this theme
      // This is a simplified approach - in production, we would use more sophisticated methods
      const connectedEmotions = emotions
        .filter(emotion => Math.random() > 0.5) // Simplified random connection for demo
        .map(emotion => ({
          name: emotion.name,
          intensity: emotion.intensity,
          confidence: Math.random() * 0.5 + 0.5 // Random confidence between 0.5 and 1.0
        }))
        .sort((a, b) => b.confidence - a.confidence);
      
      return {
        theme: theme.text,
        sentiment: theme.sentiment,
        emotions: connectedEmotions
      };
    });
  }
  
  /**
   * Generate insights based on the combined analysis
   * @param {Array} emotions - Detected emotions
   * @param {Array} emotionIntensities - Emotion intensity data
   * @param {Object} sentiment - Language sentiment
   * @param {Array} themes - Identified themes
   * @param {Array} contradictions - Identified contradictions
   * @returns {Array} - List of insights
   */
  generateInsights(emotions, emotionIntensities, sentiment, themes, contradictions) {
    const insights = [];
    
    // Insight 1: Primary emotional response
    const primaryEmotion = emotions.sort((a, b) => b.intensity - a.intensity)[0];
    insights.push({
      type: 'primary_emotion',
      title: 'Primary Emotional Response',
      description: `The dominant emotion detected is ${primaryEmotion.name} with an intensity of ${(primaryEmotion.intensity * 100).toFixed(0)}%.`,
      significance: primaryEmotion.intensity
    });
    
    // Insight 2: Sentiment-emotion alignment
    if (contradictions.length > 0) {
      const topContradiction = contradictions[0];
      insights.push({
        type: 'contradiction',
        title: 'Emotional Contradiction Detected',
        description: `The voice expresses ${topContradiction.emotion} but the language is ${topContradiction.actualSentiment}, suggesting a potential disconnect between stated opinion and emotional response.`,
        significance: topContradiction.significance
      });
    } else {
      insights.push({
        type: 'alignment',
        title: 'Aligned Emotional Response',
        description: 'The emotional tone of voice aligns with the sentiment expressed in language, indicating authentic feedback.',
        significance: 0.7
      });
    }
    
    // Insight 3: Theme-emotion connection
    if (themes.length > 0 && emotions.length > 0) {
      const topTheme = themes[0];
      insights.push({
        type: 'theme_emotion',
        title: 'Key Theme-Emotion Connection',
        description: `The theme "${topTheme.text}" appears to trigger ${emotions[0].name} responses, suggesting this aspect has significant emotional impact.`,
        significance: 0.8
      });
    }
    
    // Insight 4: Intensity analysis
    const highIntensityEmotions = emotions.filter(e => e.intensity > 0.7);
    if (highIntensityEmotions.length > 0) {
      insights.push({
        type: 'high_intensity',
        title: 'High Emotional Intensity',
        description: `Strong emotional intensity detected for ${highIntensityEmotions.map(e => e.name).join(', ')}, indicating aspects that evoke powerful responses.`,
        significance: 0.9
      });
    }
    
    // Sort by significance
    return insights.sort((a, b) => b.significance - a.significance);
  }
  
  /**
   * Create strategic recommendations based on analysis
   * @param {Array} contradictions - Identified contradictions
   * @param {Array} themeEmotionConnections - Theme-emotion connections
   * @param {Array} emotionIntensities - Emotion intensity data
   * @returns {Array} - Strategic recommendations
   */
  createRecommendations(contradictions, themeEmotionConnections, emotionIntensities) {
    const recommendations = [];
    
    // Recommendation 1: Address contradictions
    if (contradictions.length > 0) {
      recommendations.push({
        type: 'address_contradiction',
        title: 'Address Emotional Contradictions',
        description: `Further investigate why ${contradictions[0].emotion} is expressed vocally while language is ${contradictions[0].actualSentiment}. This may indicate unmet expectations or unstated concerns.`,
        priority: 'high'
      });
    }
    
    // Recommendation 2: Leverage positive themes
    const positiveThemes = themeEmotionConnections.filter(t => t.sentiment === 'positive');
    if (positiveThemes.length > 0) {
      recommendations.push({
        type: 'leverage_positive',
        title: 'Leverage Positive Themes',
        description: `Emphasize "${positiveThemes[0].theme}" in marketing and product development, as it generates positive emotional responses.`,
        priority: 'medium'
      });
    }
    
    // Recommendation 3: Address negative themes
    const negativeThemes = themeEmotionConnections.filter(t => t.sentiment === 'negative');
    if (negativeThemes.length > 0) {
      recommendations.push({
        type: 'address_negative',
        title: 'Address Negative Themes',
        description: `Prioritize improvements to "${negativeThemes[0].theme}" as it generates negative emotional responses.`,
        priority: 'high'
      });
    }
    
    // Recommendation 4: Emotional intensity focus
    const highIntensityEmotions = emotionIntensities.filter(e => e.intensity > 0.7);
    if (highIntensityEmotions.length > 0) {
      const emotion = highIntensityEmotions[0];
      if (['Joy', 'Surprise'].includes(emotion.name)) {
        recommendations.push({
          type: 'leverage_intensity',
          title: 'Leverage High-Intensity Positive Emotions',
          description: `The strong ${emotion.name} response indicates powerful positive engagement. Identify what triggers this response and amplify it in product and marketing.`,
          priority: 'medium'
        });
      } else if (['Anger', 'Sadness', 'Fear', 'Disgust'].includes(emotion.name)) {
        recommendations.push({
          type: 'address_intensity',
          title: 'Address High-Intensity Negative Emotions',
          description: `The strong ${emotion.name} response indicates significant issues that require immediate attention to prevent customer dissatisfaction.`,
          priority: 'high'
        });
      }
    }
    
    // Sort by priority
    const priorityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
    return recommendations.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  }
  
  /**
   * Analyze multiple responses and aggregate the results
   * @param {Array} responses - Array of response objects with audioUrl and transcription
   * @returns {Promise<Object>} - Aggregated analysis results
   */
  async analyzeMultipleResponses(responses) {
    try {
      logger.info(`Starting batch analysis for ${responses.length} responses`);
      
      // Analyze each response individually
      const analysisPromises = responses.map(response => 
        this.analyzeResponse(response.audioUrl, response.transcription)
      );
      
      // Wait for all analyses to complete
      const analysisResults = await Promise.all(analysisPromises);
      
      // Aggregate the results
      const aggregatedResults = this.aggregateResults(analysisResults);
      
      logger.info(`Completed batch analysis for ${responses.length} responses`);
      return aggregatedResults;
    } catch (error) {
      logger.error(`Error in batch analysis: ${error.message}`);
      throw new Error(`Batch analysis failed: ${error.message}`);
    }
  }
  
  /**
   * Aggregate results from multiple response analyses
   * @param {Array} analysisResults - Array of individual analysis results
   * @returns {Object} - Aggregated analysis
   */
  aggregateResults(analysisResults) {
    try {
      // Initialize aggregation structures
      const emotionData = {};
      const languageData = { positive: 0, negative: 0, neutral: 0 };
      const themeData = {};
      const correlationData = {};
      const contradictions = [];
      const themeEmotionConnections = [];
      
      // Process each analysis result
      analysisResults.forEach(analysis => {
        // Aggregate emotion data
        analysis.emotionResults.emotions.forEach(emotion => {
          if (!emotionData[emotion.name]) {
            emotionData[emotion.name] = { count: 0, totalIntensity: 0 };
          }
          emotionData[emotion.name].count += 1;
          emotionData[emotion.name].totalIntensity += emotion.intensity;
        });
        
        // Aggregate language sentiment
        languageData.positive += analysis.languageResults.sentiment.positive;
        languageData.negative += analysis.languageResults.sentiment.negative;
        languageData.neutral += analysis.languageResults.sentiment.neutral;
        
        // Aggregate themes
        analysis.languageResults.themes.forEach(theme => {
          if (!themeData[theme.text]) {
            themeData[theme.text] = { count: 0, sentiment: theme.sentiment, emotions: {} };
          }
          themeData[theme.text].count += 1;
        });
        
        // Collect all contradictions
        contradictions.push(...analysis.contradictions);
        
        // Collect theme-emotion connections
        themeEmotionConnections.push(...analysis.themeEmotionConnections);
      });
      
      // Calculate averages and percentages
      const totalResponses = analysisResults.length;
      
      // Convert emotion data to array format
      const emotionDataArray = Object.entries(emotionData).map(([name, data]) => ({
        name,
        value: Math.round((data.count / totalResponses) * 100),
        intensity: data.totalIntensity / data.count
      }));
      
      // Normalize language data
      const totalSentiment = languageData.positive + languageData.negative + languageData.neutral;
      const languageDataArray = [
        { category: 'Positive', value: Math.round((languageData.positive / totalSentiment) * 100) },
        { category: 'Negative', value: Math.round((languageData.negative / totalSentiment) * 100) },
        { category: 'Neutral', value: Math.round((languageData.neutral / totalSentiment) * 100) }
      ];
      
      // Convert theme data to array format
      const themeDataArray = Object.entries(themeData)
        .map(([text, data]) => ({
          theme: text,
          count: data.count,
          sentiment: data.sentiment
        }))
        .sort((a, b) => b.count - a.count);
      
      // Aggregate correlation data
      const correlationDataMap = {};
      analysisResults.forEach(analysis => {
        analysis.correlationData.forEach(item => {
          if (!correlationDataMap[item.emotion]) {
            correlationDataMap[item.emotion] = {
              positiveLanguage: 0,
              neutralLanguage: 0,
              negativeLanguage: 0,
              count: 0
            };
          }
          correlationDataMap[item.emotion].positiveLanguage += item.positiveLanguage;
          correlationDataMap[item.emotion].neutralLanguage += item.neutralLanguage;
          correlationDataMap[item.emotion].negativeLanguage += item.negativeLanguage;
          correlationDataMap[item.emotion].count += 1;
        });
      });
      
      // Calculate average correlation data
      const correlationDataArray = Object.entries(correlationDataMap).map(([emotion, data]) => ({
        emotion,
        positiveLanguage: Math.round(data.positiveLanguage / data.count),
        neutralLanguage: Math.round(data.neutralLanguage / data.count),
        negativeLanguage: Math.round(data.negativeLanguage / data.count)
      }));
      
      // Generate insights and recommendations based on aggregated data
      const insights = this.generateAggregatedInsights(
        emotionDataArray,
        languageDataArray,
        themeDataArray,
        contradictions
      );
      
      const recommendations = this.createAggregatedRecommendations(
        contradictions,
        themeEmotionConnections,
        emotionDataArray
      );
      
      return {
        emotionData: emotionDataArray,
        languageData: languageDataArray,
        keyThemes: themeDataArray.slice(0, 5), // Top 5 themes
        emotionLanguageCorrelation: correlationDataArray,
        topContradictions: contradictions.slice(0, 3), // Top 3 contradictions
        insights,
        recommendations
      };
    } catch (error) {
      logger.error(`Error in result aggregation: ${error.message}`);
      throw new Error(`Result aggregation failed: ${error.message}`);
    }
  }
  
  /**
   * Generate insights based on aggregated data
   * @param {Array} emotionData - Aggregated emotion data
   * @param {Array} languageData - Aggregated language data
   * @param {Array} themeData - Aggregated theme data
   * @param {Array} contradictions - All identified contradictions
   * @returns {Array} - List of insights
   */
  generateAggregatedInsights(emotionData, languageData, themeData, contradictions) {
    // Similar to generateInsights but works with aggregated data
    // Implementation would be similar to the individual analysis version
    // but adapted for aggregated data structures
    
    const insights = [];
    
    // Insight 1: Primary emotional response
    if (emotionData.length > 0) {
      const primaryEmotion = emotionData.sort((a, b) => b.value - a.value)[0];
      insights.push({
        type: 'primary_emotion',
        title: 'Primary Emotional Response',
        description: `The dominant emotion across responses is ${primaryEmotion.name} (${primaryEmotion.value}% of responses).`,
        significance: primaryEmotion.value / 100
      });
    }
    
    // Insight 2: Sentiment overview
    const positiveSentiment = languageData.find(item => item.category === 'Positive')?.value || 0;
    const negativeSentiment = languageData.find(item => item.category === 'Negative')?.value || 0;
    
    if (positiveSentiment > negativeSentiment) {
      insights.push({
        type: 'sentiment_overview',
        title: 'Positive Sentiment Dominance',
        description: `Overall sentiment is predominantly positive (${positiveSentiment}% of language), indicating general satisfaction.`,
        significance: positiveSentiment / 100
      });
    } else if (negativeSentiment > positiveSentiment) {
      insights.push({
        type: 'sentiment_overview',
        title: 'Negative Sentiment Concerns',
        description: `Overall sentiment shows significant negative language (${negativeSentiment}%), indicating areas of concern.`,
        significance: negativeSentiment / 100
      });
    }
    
    // Insight 3: Contradiction patterns
    if (contradictions.length > 0) {
      // Group contradictions by emotion
      const contradictionsByEmotion = {};
      contradictions.forEach(c => {
        if (!contradictionsByEmotion[c.emotion]) {
          contradictionsByEmotion[c.emotion] = [];
        }
        contradictionsByEmotion[c.emotion].push(c);
      });
      
      // Find the most common contradiction
      let mostCommonEmotion = '';
      let maxCount = 0;
      
      Object.entries(contradictionsByEmotion).forEach(([emotion, contradictions]) => {
        if (contradictions.length > maxCount) {
          mostCommonEmotion = emotion;
          maxCount = contradictions.length;
        }
      });
      
      if (mostCommonEmotion) {
        insights.push({
          type: 'contradiction_pattern',
          title: 'Emotional Contradiction Pattern',
          description: `${mostCommonEmotion} is frequently expressed in voice while language contradicts this emotion, suggesting potential hidden feelings.`,
          significance: 0.8
        });
      }
    }
    
    // Insight 4: Theme-emotion patterns
    if (themeData.length > 0) {
      const topPositiveTheme = themeData.find(t => t.sentiment === 'positive');
      const topNegativeTheme = themeData.find(t => t.sentiment === 'negative');
      
      if (topPositiveTheme) {
        insights.push({
          type: 'positive_theme',
          title: 'Top Positive Theme',
          description: `"${topPositiveTheme.theme}" is the most frequently mentioned positive theme (${topPositiveTheme.count} mentions).`,
          significance: 0.7
        });
      }
      
      if (topNegativeTheme) {
        insights.push({
          type: 'negative_theme',
          title: 'Top Negative Theme',
          description: `"${topNegativeTheme.theme}" is the most frequently mentioned negative theme (${topNegativeTheme.count} mentions).`,
          significance: 0.75
        });
      }
    }
    
    // Sort by significance
    return insights.sort((a, b) => b.significance - a.significance);
  }
  
  /**
   * Create strategic recommendations based on aggregated analysis
   * @param {Array} contradictions - All identified contradictions
   * @param {Array} themeEmotionConnections - All theme-emotion connections
   * @param {Array} emotionData - Aggregated emotion data
   * @returns {Array} - Strategic recommendations
   */
  createAggregatedRecommendations(contradictions, themeEmotionConnections, emotionData) {
    // Similar to createRecommendations but works with aggregated data
    // Implementation would be similar to the individual analysis version
    // but adapted for aggregated data structures
    
    const recommendations = [];
    
    // Recommendation 1: Address common contradictions
    if (contradictions.length > 0) {
      // Group contradictions by emotion
      const contradictionsByEmotion = {};
      contradictions.forEach(c => {
        if (!contradictionsByEmotion[c.emotion]) {
          contradictionsByEmotion[c.emotion] = [];
        }
        contradictionsByEmotion[c.emotion].push(c);
      });
      
      // Find the most common contradiction
      let mostCommonEmotion = '';
      let maxCount = 0;
      
      Object.entries(contradictionsByEmotion).forEach(([emotion, contradictions]) => {
        if (contradictions.length > maxCount) {
          mostCommonEmotion = emotion;
          maxCount = contradictions.length;
        }
      });
      
      if (mostCommonEmotion) {
        recommendations.push({
          type: 'address_common_contradiction',
          title: `Address ${mostCommonEmotion} Contradictions`,
          description: `Investigate why ${mostCommonEmotion} is frequently expressed vocally while language contradicts this emotion. This pattern suggests customers may not be fully expressing their true feelings in words.`,
          priority: 'high'
        });
      }
    }
    
    // Recommendation 2: Theme-based improvements
    // Group theme-emotion connections by theme
    const themeEmotionMap = {};
    themeEmotionConnections.forEach(connection => {
      if (!themeEmotionMap[connection.theme]) {
        themeEmotionMap[connection.theme] = {
          sentiment: connection.sentiment,
          emotions: {}
        };
      }
      
      connection.emotions.forEach(emotion => {
        if (!themeEmotionMap[connection.theme].emotions[emotion.name]) {
          themeEmotionMap[connection.theme].emotions[emotion.name] = {
            count: 0,
            totalIntensity: 0,
            totalConfidence: 0
          };
        }
        
        themeEmotionMap[connection.theme].emotions[emotion.name].count += 1;
        themeEmotionMap[connection.theme].emotions[emotion.name].totalIntensity += emotion.intensity;
        themeEmotionMap[connection.theme].emotions[emotion.name].totalConfidence += emotion.confidence;
      });
    });
    
    // Find themes with strong negative emotions
    const themesWithNegativeEmotions = Object.entries(themeEmotionMap)
      .filter(([_, data]) => {
        const emotions = Object.entries(data.emotions);
        return emotions.some(([emotion, stats]) => 
          ['Anger', 'Sadness', 'Fear', 'Disgust'].includes(emotion) && 
          stats.count > 2 && 
          stats.totalIntensity / stats.count > 0.6
        );
      })
      .map(([theme, data]) => ({
        theme,
        sentiment: data.sentiment,
        strongestNegativeEmotion: Object.entries(data.emotions)
          .filter(([emotion, _]) => ['Anger', 'Sadness', 'Fear', 'Disgust'].includes(emotion))
          .sort(([_, a], [__, b]) => (b.totalIntensity / b.count) - (a.totalIntensity / a.count))[0]?.[0]
      }));
    
    if (themesWithNegativeEmotions.length > 0) {
      const topTheme = themesWithNegativeEmotions[0];
      recommendations.push({
        type: 'address_negative_theme',
        title: `Improve "${topTheme.theme}"`,
        description: `Prioritize improvements to "${topTheme.theme}" as it consistently triggers ${topTheme.strongestNegativeEmotion} responses from customers.`,
        priority: 'high'
      });
    }
    
    // Find themes with strong positive emotions
    const themesWithPositiveEmotions = Object.entries(themeEmotionMap)
      .filter(([_, data]) => {
        const emotions = Object.entries(data.emotions);
        return emotions.some(([emotion, stats]) => 
          ['Joy', 'Surprise'].includes(emotion) && 
          stats.count > 2 && 
          stats.totalIntensity / stats.count > 0.6
        );
      })
      .map(([theme, data]) => ({
        theme,
        sentiment: data.sentiment,
        strongestPositiveEmotion: Object.entries(data.emotions)
          .filter(([emotion, _]) => ['Joy', 'Surprise'].includes(emotion))
          .sort(([_, a], [__, b]) => (b.totalIntensity / b.count) - (a.totalIntensity / a.count))[0]?.[0]
      }));
    
    if (themesWithPositiveEmotions.length > 0) {
      const topTheme = themesWithPositiveEmotions[0];
      recommendations.push({
        type: 'leverage_positive_theme',
        title: `Leverage "${topTheme.theme}"`,
        description: `Emphasize "${topTheme.theme}" in marketing and product development as it consistently generates ${topTheme.strongestPositiveEmotion} responses from customers.`,
        priority: 'medium'
      });
    }
    
    // Recommendation 3: Emotion-based strategy
    // Find the most intense emotion
    const mostIntenseEmotion = emotionData
      .sort((a, b) => b.intensity - a.intensity)[0];
    
    if (mostIntenseEmotion) {
      if (['Joy', 'Surprise'].includes(mostIntenseEmotion.name)) {
        recommendations.push({
          type: 'leverage_intense_positive',
          title: `Leverage Intense ${mostIntenseEmotion.name}`,
          description: `The high intensity of ${mostIntenseEmotion.name} (${(mostIntenseEmotion.intensity * 100).toFixed(0)}% intensity) indicates strong positive engagement. Identify what triggers this response and amplify it across product experience.`,
          priority: 'medium'
        });
      } else if (['Anger', 'Sadness', 'Fear', 'Disgust'].includes(mostIntenseEmotion.name)) {
        recommendations.push({
          type: 'address_intense_negative',
          title: `Address Intense ${mostIntenseEmotion.name}`,
          description: `The high intensity of ${mostIntenseEmotion.name} (${(mostIntenseEmotion.intensity * 100).toFixed(0)}% intensity) indicates significant issues that require immediate attention to prevent customer dissatisfaction.`,
          priority: 'high'
        });
      }
    }
    
    // Sort by priority
    const priorityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
    return recommendations.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  }
}

export const mixedAnalysisService = new MixedAnalysisService();
