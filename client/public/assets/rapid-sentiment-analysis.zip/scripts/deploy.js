const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// Configuration
const config = {
  projectDir: path.resolve(__dirname, '..'),
  clientDir: path.resolve(__dirname, '../client'),
  buildDir: path.resolve(__dirname, '../client/build'),
  serverPort: process.env.PORT || 3000
};

// Build client
const buildClient = () => {
  console.log('Building client application...');
  execSync('npm run build', { cwd: config.clientDir, stdio: 'inherit' });
  console.log('✅ Client built successfully');
};

// Start server
const startServer = () => {
  console.log(`Starting server on port ${config.serverPort}...`);
  execSync('npm start', { cwd: config.projectDir, stdio: 'inherit' });
};

// Main deployment function
const deploy = async () => {
  try {
    console.log('Starting deployment process...');
    
    // Build client
    buildClient();
    
    // Start server
    startServer();
    
    console.log('✅ Deployment completed successfully');
  } catch (error) {
    console.error('❌ Deployment failed:', error.message);
    process.exit(1);
  }
};

// Run deployment
deploy();