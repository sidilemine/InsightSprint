import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Button, 
  Chip, 
  Divider, 
  Tabs, 
  Tab, 
  CircularProgress,
  Alert,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import { 
  Edit as EditIcon,
  Assessment as AssessmentIcon,
  Send as SendIcon,
  People as PeopleIcon,
  QuestionAnswer as QuestionAnswerIcon,
  InsightsOutlined as InsightsIcon,
  CheckCircleOutline as CheckCircleIcon,
  PendingOutlined as PendingIcon
} from '@mui/icons-material';
import { useParams, Link } from 'react-router-dom';

const ProjectDetail = () => {
  const { projectId } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [project, setProject] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  
  useEffect(() => {
    const fetchProjectDetails = async () => {
      try {
        setLoading(true);
        setError('');
        
        // In a real implementation, this would fetch data from the API
        // For now, we'll use mock data
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data
        const mockProject = {
          id: projectId,
          name: 'Beverage Product Testing',
          description: 'Consumer feedback on new beverage product line',
          objective: 'Understand consumer perception and emotional response to our new line of plant-based beverages',
          category: 'beverage',
          status: 'active',
          progress: 65,
          targetResponseCount: 50,
          responseCount: 42,
          createdAt: '2025-04-10T14:30:00Z',
          updatedAt: '2025-04-15T09:22:00Z',
          questions: [
            {
              id: 1,
              text: 'What are your first impressions of this new beverage concept?',
              type: 'open_ended'
            },
            {
              id: 2,
              text: 'How would you rate the appeal of the packaging design on a scale of 1-5?',
              type: 'scale'
            },
            {
              id: 3,
              text: 'What emotions do you feel when you think about trying this product?',
              type: 'open_ended'
            },
            {
              id: 4,
              text: 'Would you consider purchasing this product when it becomes available?',
              type: 'yes_no'
            },
            {
              id: 5,
              text: 'What improvements would you suggest for this product?',
              type: 'open_ended'
            }
          ],
          participantCriteria: {
            ageRange: '25-44',
            gender: 'all',
            location: 'us',
            customCriteria: 'Regular consumers of plant-based beverages (at least once per week)'
          },
          responses: [
            {
              id: 'resp-1',
              participantId: 'part-101',
              completedAt: '2025-04-12T10:15:00Z',
              duration: 420, // seconds
              status: 'completed'
            },
            {
              id: 'resp-2',
              participantId: 'part-102',
              completedAt: '2025-04-12T11:30:00Z',
              duration: 380,
              status: 'completed'
            },
            {
              id: 'resp-3',
              participantId: 'part-103',
              completedAt: '2025-04-12T14:45:00Z',
              duration: 450,
              status: 'completed'
            }
            // Additional responses would be here in a real implementation
          ],
          preliminaryResults: {
            responseRate: 84, // percentage
            averageDuration: 410, // seconds
            completionRate: 95, // percentage
            emotionSummary: [
              { emotion: 'Interest', percentage: 45 },
              { emotion: 'Joy', percentage: 30 },
              { emotion: 'Surprise', percentage: 15 },
              { emotion: 'Skepticism', percentage: 10 }
            ],
            keyThemes: [
              'Packaging design',
              'Taste expectations',
              'Health benefits',
              'Environmental impact',
              'Price point'
            ]
          }
        };
        
        setProject(mockProject);
        setLoading(false);
      } catch (err) {
        setError('Failed to load project details. Please try again.');
        setLoading(false);
      }
    };
    
    fetchProjectDetails();
  }, [projectId]);
  
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };
  
  const formatDuration = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'success';
      case 'completed':
        return 'primary';
      case 'draft':
        return 'default';
      default:
        return 'default';
    }
  };
  
  const renderOverviewTab = () => {
    return (
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Project Details
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography variant="subtitle2" color="text.secondary">
                  Description
                </Typography>
                <Typography variant="body1" paragraph>
                  {project.description}
                </Typography>
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="subtitle2" color="text.secondary">
                  Research Objective
                </Typography>
                <Typography variant="body1" paragraph>
                  {project.objective}
                </Typography>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Category
                </Typography>
                <Typography variant="body1" paragraph>
                  {project.category.charAt(0).toUpperCase() + project.category.slice(1)}
                </Typography>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Status
                </Typography>
                <Chip 
                  label={project.status.charAt(0).toUpperCase() + project.status.slice(1)} 
                  color={getStatusColor(project.status)}
                  size="small"
                />
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Created
                </Typography>
                <Typography variant="body1">
                  {formatDate(project.createdAt)}
                </Typography>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Last Updated
                </Typography>
                <Typography variant="body1">
                  {formatDate(project.updatedAt)}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Interview Questions
            </Typography>
            
            <List>
              {project.questions.map((question, index) => (
                <React.Fragment key={question.id}>
                  <ListItem alignItems="flex-start">
                    <ListItemIcon sx={{ minWidth: 36 }}>
                      <QuestionAnswerIcon color="primary" />
                    </ListItemIcon>
                    <ListItemText
                      primary={
                        <Typography variant="subtitle1">
                          Question {index + 1}: {question.text}
                        </Typography>
                      }
                      secondary={
                        <Typography variant="body2" color="text.secondary">
                          Type: {question.type.replace('_', ' ').charAt(0).toUpperCase() + question.type.replace('_', ' ').slice(1)}
                        </Typography>
                      }
                    />
                  </ListItem>
                  {index < project.questions.length - 1 && <Divider variant="inset" component="li" />}
                </React.Fragment>
              ))}
            </List>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Progress
            </Typography>
            
            <Box display="flex" alignItems="center" mb={1}>
              <Box width="100%" mr={1}>
                <LinearProgress variant="determinate" value={project.progress} sx={{ height: 10, borderRadius: 5 }} />
              </Box>
              <Box minWidth={35}>
                <Typography variant="body2" color="text.secondary">
                  {project.progress}%
                </Typography>
              </Box>
            </Box>
            
            <Box display="flex" justifyContent="space-between" mt={2}>
              <Box>
                <Typography variant="subtitle2" color="text.secondary">
                  Responses
                </Typography>
                <Typography variant="h6">
                  {project.responseCount} / {project.targetResponseCount}
                </Typography>
              </Box>
              
              <Box>
                <Typography variant="subtitle2" color="text.secondary" align="right">
                  Completion
                </Typography>
                <Typography variant="h6" align="right">
                  {Math.round((project.responseCount / project.targetResponseCount) * 100)}%
                </Typography>
              </Box>
            </Box>
          </Paper>
          
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Participant Criteria
            </Typography>
            
            <List dense>
              <ListItem>
                <ListItemIcon>
                  <PeopleIcon />
                </ListItemIcon>
                <ListItemText 
                  primary="Age Range" 
                  secondary={project.participantCriteria.ageRange} 
                />
              </ListItem>
              
              <ListItem>
                <ListItemIcon>
                  <PeopleIcon />
                </ListItemIcon>
                <ListItemText 
                  primary="Gender" 
                  secondary={
                    project.participantCriteria.gender === 'all'
                      ? 'All Genders'
                      : project.participantCriteria.gender.charAt(0).toUpperCase() + 
                        project.participantCriteria.gender.slice(1)
                  } 
                />
              </ListItem>
              
              <ListItem>
                <ListItemIcon>
                  <PeopleIcon />
                </ListItemIcon>
                <ListItemText 
                  primary="Location" 
                  secondary={
                    project.participantCriteria.location === 'all'
                      ? 'All Locations'
                      : project.participantCriteria.location === 'us'
                        ? 'United States'
                        : project.participantCriteria.location.charAt(0).toUpperCase() + 
                          project.participantCriteria.location.slice(1)
                  } 
                />
              </ListItem>
              
              {project.participantCriteria.customCriteria && (
                <ListItem>
                  <ListItemIcon>
                    <PeopleIcon />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Additional Criteria" 
                    secondary={project.participantCriteria.customCriteria} 
                  />
                </ListItem>
              )}
            </List>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Actions
            </Typography>
            
            <Button
              fullWidth
              variant="contained"
              color="primary"
              startIcon={<AssessmentIcon />}
              component={Link}
              to={`/admin/projects/${project.id}/analysis`}
              sx={{ mb: 2 }}
              disabled={project.status !== 'completed'}
            >
              View Analysis
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              startIcon={<EditIcon />}
              component={Link}
              to={`/admin/projects/${project.id}/edit`}
              sx={{ mb: 2 }}
            >
              Edit Project
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              color="secondary"
              startIcon={<SendIcon />}
              component={Link}
              to={`/admin/projects/${project.id}/share`}
            >
              Share Results
            </Button>
          </Paper>
        </Grid>
      </Grid>
    );
  };
  
  const renderResponsesTab = () => {
    return (
      <Paper sx={{ p: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
          <Typography variant="h6">
            Responses ({project.responses.length})
          </Typography>
          
          <Button
            variant="outlined"
            startIcon={<PeopleIcon />}
          >
            Invite Participants
          </Button>
        </Box>
        
        <Grid container spacing={2}>
          {project.responses.map((response) => (
            <Grid item xs={12} md={6} lg={4} key={response.id}>
              <Card variant="outlined">
                <CardContent>
                  <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                    <Typography variant="subtitle1">
                      Participant {response.participantId.split('-')[1]}
                    </Typography>
                    <Chip 
                      icon={response.status === 'completed' ? <CheckCircleIcon /> : <PendingIcon />}
                      label={response.status.charAt(0).toUpperCase() + response.status.slice(1)} 
                      color={response.status === 'completed' ? 'success' : 'default'}
                      size="small"
                    />
                  </Box>
                  
                  <Divider sx={{ my: 1 }} />
                  
                  <Grid container spacing={1}>
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        Completed
                      </Typography>
                      <Typography variant="body2">
                        {formatDate(response.completedAt)}
                      </Typography>
                    </Grid>
                    
                    <Grid item xs={6}>
                      <Typography variant="body2" color="text.secondary">
                        Duration
                      </Typography>
                      <Typography variant="body2">
                        {formatDuration(response.duration)}
                      </Typography>
                    </Grid>
                  </Grid>
                  
                  <Button
                    fullWidth
                    variant="text"
                    size="small"
                    component={Link}
                    to={`/admin/responses/${response.id}`}
                    sx={{ mt: 2 }}
                  >
                    View Details
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Paper>
    );
  };
  
  const renderPreliminaryResultsTab = () => {
    return (
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Response Statistics
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Response Rate
                </Typography>
                <Typography variant="h5">
                  {project.preliminaryResults.responseRate}%
                </Typography>
              </Grid>
              
              <Grid item xs={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Completion Rate
                </Typography>
                <Typography variant="h5">
                  {project.preliminaryResults.completionRate}%
                </Typography>
              </Grid>
              
              <Grid item xs={12}>
                <Divider sx={{ my: 1 }} />
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="subtitle2" color="text.secondary">
                  Average Interview Duration
                </Typography>
                <Typography variant="h5">
                  {formatDuration(project.preliminaryResults.averageDuration)}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Preliminary Emotion Analysis
            </Typography>
            
            <List>
              {project.preliminaryResults.emotionSummary.map((emotion) => (
                <ListItem key={emotion.emotion} disableGutters>
                  <ListItemText 
                    primary={
                      <Box display="flex" alignItems="center">
                        <Typography variant="body1" sx={{ minWidth: 100 }}>
                          {emotion.emotion}
                        </Typography>
                        <Box width="100%" mr={1} ml={2}>
                          <LinearProgress 
                            variant="determinate" 
                            value={emotion.percentage} 
                            sx={{ height: 10, borderRadius: 5 }} 
                          />
                        </Box>
                        <Typography variant="body2" color="text.secondary">
                          {emotion.percentage}%
                        </Typography>
                      </Box>
                    }
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
        
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Key Themes Identified
            </Typography>
            
            <Box display="flex" flexWrap="wrap" gap={1} mt={2}>
              {project.preliminaryResults.keyThemes.map((theme) => (
                <Chip 
                  key={theme}
                  label={theme}
                  icon={<InsightsIcon />}
                  variant="outlined"
                  color="primary"
                />
              ))}
            </Box>
            
            <Box mt={3} display="flex" justifyContent="center">
              <Button
                variant="contained"
                color="primary"
                startIcon={<AssessmentIcon />}
                component={Link}
                to={`/admin/projects/${project.id}/analysis`}
                disabled={project.status !== 'completed'}
              >
                Generate Full Analysis
              </Button>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    );
  };
  
  // Define LinearProgress component for use in the component
  const LinearProgress = ({ variant, value, sx }) => {
    return (
      <Box sx={{ width: '100%', bgcolor: 'background.paper', borderRadius: sx?.borderRadius || 0, ...sx }}>
        <Box
          sx={{
            width: `${value}%`,
            height: sx?.height || 4,
            bgcolor: 'primary.main',
            borderRadius: sx?.borderRadius || 0,
          }}
        />
      </Box>
    );
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {loading ? (
        <Box display="flex" justifyContent="center" my={5}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      ) : project ? (
        <>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
            <Typography variant="h4" component="h1">
              {project.name}
            </Typography>
            
            <Chip 
              label={project.status.charAt(0).toUpperCase() + project.status.slice(1)} 
              color={getStatusColor(project.status)}
            />
          </Box>
          
          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
            <Tabs value={tabValue} onChange={handleTabChange} aria-label="project tabs">
              <Tab label="Overview" />
              <Tab label="Responses" />
              <Tab label="Preliminary Results" />
            </Tabs>
          </Box>
          
          {tabValue === 0 && renderOverviewTab()}
          {tabValue === 1 && renderResponsesTab()}
          {tabValue === 2 && renderPreliminaryResultsTab()}
        </>
      ) : (
        <Alert severity="error">
          Project not found
        </Alert>
      )}
    </Container>
  );
};

export default ProjectDetail;
