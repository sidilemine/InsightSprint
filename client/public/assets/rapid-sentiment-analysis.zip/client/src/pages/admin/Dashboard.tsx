import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Box, 
  Button, 
  Card, 
  CardContent, 
  CardActions,
  Divider,
  CircularProgress,
  Alert
} from '@mui/material';
import { 
  Add as AddIcon,
  Assessment as AssessmentIcon,
  People as PeopleIcon,
  Insights as InsightsIcon
} from '@mui/icons-material';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState({
    totalProjects: 0,
    activeProjects: 0,
    completedAnalyses: 0,
    totalResponses: 0
  });
  const [recentProjects, setRecentProjects] = useState([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        setError('');
        
        // In a real implementation, this would fetch data from the API
        // For now, we'll use mock data
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data
        setStats({
          totalProjects: 5,
          activeProjects: 2,
          completedAnalyses: 8,
          totalResponses: 124
        });
        
        setRecentProjects([
          {
            id: 'project-1',
            name: 'Beverage Product Testing',
            status: 'active',
            progress: 65,
            responseCount: 42,
            createdAt: '2025-04-10T14:30:00Z'
          },
          {
            id: 'project-2',
            name: 'Snack Packaging Feedback',
            status: 'active',
            progress: 80,
            responseCount: 38,
            createdAt: '2025-04-05T09:15:00Z'
          },
          {
            id: 'project-3',
            name: 'Dairy Alternative Concept',
            status: 'completed',
            progress: 100,
            responseCount: 44,
            createdAt: '2025-03-28T11:45:00Z'
          }
        ]);
        
        setLoading(false);
      } catch (err) {
        setError('Failed to load dashboard data. Please try again.');
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Dashboard
        </Typography>
        <Button 
          variant="contained" 
          color="primary" 
          startIcon={<AddIcon />}
          component={Link}
          to="/admin/projects/new"
        >
          New Project
        </Button>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      {loading ? (
        <Box display="flex" justifyContent="center" my={5}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          {/* Stats Cards */}
          <Grid container spacing={3} mb={4}>
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={2} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140 }}>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Total Projects
                </Typography>
                <Typography component="p" variant="h3" sx={{ flexGrow: 1 }}>
                  {stats.totalProjects}
                </Typography>
                <Typography color="text.secondary" sx={{ fontSize: '0.875rem' }}>
                  {stats.activeProjects} active
                </Typography>
              </Paper>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={2} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140 }}>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Completed Analyses
                </Typography>
                <Typography component="p" variant="h3" sx={{ flexGrow: 1 }}>
                  {stats.completedAnalyses}
                </Typography>
                <Typography color="text.secondary" sx={{ fontSize: '0.875rem' }}>
                  Insights generated
                </Typography>
              </Paper>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={2} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140 }}>
                <Typography variant="h6" color="text.secondary" gutterBottom>
                  Total Responses
                </Typography>
                <Typography component="p" variant="h3" sx={{ flexGrow: 1 }}>
                  {stats.totalResponses}
                </Typography>
                <Typography color="text.secondary" sx={{ fontSize: '0.875rem' }}>
                  Voice interviews collected
                </Typography>
              </Paper>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Paper elevation={2} sx={{ p: 2, display: 'flex', flexDirection: 'column', height: 140, bgcolor: 'primary.light', color: 'white' }}>
                <Typography variant="h6" gutterBottom>
                  Quick Actions
                </Typography>
                <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                  <Button 
                    variant="contained" 
                    size="small" 
                    sx={{ mb: 1, bgcolor: 'primary.main' }}
                    component={Link}
                    to="/admin/projects/new"
                  >
                    New Project
                  </Button>
                  <Button 
                    variant="outlined" 
                    size="small" 
                    sx={{ color: 'white', borderColor: 'white' }}
                    component={Link}
                    to="/admin/reports"
                  >
                    View Reports
                  </Button>
                </Box>
              </Paper>
            </Grid>
          </Grid>
          
          {/* Recent Projects */}
          <Typography variant="h5" component="h2" mb={2}>
            Recent Projects
          </Typography>
          
          <Grid container spacing={3}>
            {recentProjects.map((project) => (
              <Grid item xs={12} md={4} key={project.id}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" component="div" gutterBottom>
                      {project.name}
                    </Typography>
                    
                    <Box display="flex" justifyContent="space-between" mb={1}>
                      <Typography variant="body2" color="text.secondary">
                        Status:
                      </Typography>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          color: project.status === 'active' ? 'success.main' : 'text.secondary',
                          fontWeight: 'medium'
                        }}
                      >
                        {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                      </Typography>
                    </Box>
                    
                    <Box display="flex" justifyContent="space-between" mb={1}>
                      <Typography variant="body2" color="text.secondary">
                        Progress:
                      </Typography>
                      <Typography variant="body2">
                        {project.progress}%
                      </Typography>
                    </Box>
                    
                    <Box display="flex" justifyContent="space-between" mb={1}>
                      <Typography variant="body2" color="text.secondary">
                        Responses:
                      </Typography>
                      <Typography variant="body2">
                        {project.responseCount}
                      </Typography>
                    </Box>
                    
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2" color="text.secondary">
                        Created:
                      </Typography>
                      <Typography variant="body2">
                        {formatDate(project.createdAt)}
                      </Typography>
                    </Box>
                  </CardContent>
                  
                  <Divider />
                  
                  <CardActions>
                    <Button 
                      size="small" 
                      startIcon={<InsightsIcon />}
                      component={Link}
                      to={`/admin/projects/${project.id}`}
                    >
                      View Details
                    </Button>
                    
                    {project.status === 'completed' && (
                      <Button 
                        size="small" 
                        color="secondary" 
                        startIcon={<AssessmentIcon />}
                        component={Link}
                        to={`/admin/projects/${project.id}/analysis`}
                      >
                        View Analysis
                      </Button>
                    )}
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        </>
      )}
    </Container>
  );
};

export default Dashboard;
