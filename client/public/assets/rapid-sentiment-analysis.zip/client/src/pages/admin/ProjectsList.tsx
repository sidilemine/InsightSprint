import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Button, 
  Paper, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow,
  TablePagination,
  Chip,
  IconButton,
  TextField,
  InputAdornment,
  CircularProgress,
  Alert
} from '@mui/material';
import { 
  Add as AddIcon,
  Search as SearchIcon,
  Visibility as VisibilityIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Assessment as AssessmentIcon
} from '@mui/icons-material';
import { Link } from 'react-router-dom';

const ProjectsList = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        setError('');
        
        // In a real implementation, this would fetch data from the API
        // For now, we'll use mock data
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data
        const mockProjects = [
          {
            id: 'project-1',
            name: 'Beverage Product Testing',
            description: 'Consumer feedback on new beverage product line',
            status: 'active',
            progress: 65,
            responseCount: 42,
            createdAt: '2025-04-10T14:30:00Z',
            updatedAt: '2025-04-15T09:22:00Z'
          },
          {
            id: 'project-2',
            name: 'Snack Packaging Feedback',
            description: 'Evaluation of new sustainable packaging designs',
            status: 'active',
            progress: 80,
            responseCount: 38,
            createdAt: '2025-04-05T09:15:00Z',
            updatedAt: '2025-04-14T16:45:00Z'
          },
          {
            id: 'project-3',
            name: 'Dairy Alternative Concept',
            description: 'Consumer perception of new plant-based dairy alternatives',
            status: 'completed',
            progress: 100,
            responseCount: 44,
            createdAt: '2025-03-28T11:45:00Z',
            updatedAt: '2025-04-08T10:30:00Z'
          },
          {
            id: 'project-4',
            name: 'Organic Cereal Brand Positioning',
            description: 'Testing brand messaging for new organic cereal line',
            status: 'completed',
            progress: 100,
            responseCount: 50,
            createdAt: '2025-03-15T08:20:00Z',
            updatedAt: '2025-03-30T14:15:00Z'
          },
          {
            id: 'project-5',
            name: 'Premium Chocolate Taste Test',
            description: 'Comparative analysis of premium chocolate varieties',
            status: 'draft',
            progress: 0,
            responseCount: 0,
            createdAt: '2025-04-16T11:10:00Z',
            updatedAt: '2025-04-16T11:10:00Z'
          }
        ];
        
        setProjects(mockProjects);
        setFilteredProjects(mockProjects);
        setLoading(false);
      } catch (err) {
        setError('Failed to load projects. Please try again.');
        setLoading(false);
      }
    };
    
    fetchProjects();
  }, []);

  useEffect(() => {
    // Filter projects based on search term
    if (searchTerm.trim() === '') {
      setFilteredProjects(projects);
    } else {
      const filtered = projects.filter(project => 
        project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredProjects(filtered);
    }
    
    // Reset to first page when search changes
    setPage(0);
  }, [searchTerm, projects]);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'success';
      case 'completed':
        return 'primary';
      case 'draft':
        return 'default';
      default:
        return 'default';
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Projects
        </Typography>
        <Button 
          variant="contained" 
          color="primary" 
          startIcon={<AddIcon />}
          component={Link}
          to="/admin/projects/new"
        >
          New Project
        </Button>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ width: '100%', mb: 2 }}>
        <Box p={2}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search projects..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            sx={{ mb: 2 }}
          />
          
          {loading ? (
            <Box display="flex" justifyContent="center" my={5}>
              <CircularProgress />
            </Box>
          ) : (
            <>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Project Name</TableCell>
                      <TableCell>Description</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Responses</TableCell>
                      <TableCell>Created</TableCell>
                      <TableCell>Last Updated</TableCell>
                      <TableCell align="right">Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {filteredProjects
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((project) => (
                        <TableRow key={project.id}>
                          <TableCell component="th" scope="row">
                            <Link 
                              to={`/admin/projects/${project.id}`}
                              style={{ textDecoration: 'none', color: 'inherit', fontWeight: 'medium' }}
                            >
                              {project.name}
                            </Link>
                          </TableCell>
                          <TableCell>{project.description}</TableCell>
                          <TableCell>
                            <Chip 
                              label={project.status.charAt(0).toUpperCase() + project.status.slice(1)} 
                              color={getStatusColor(project.status)}
                              size="small"
                            />
                          </TableCell>
                          <TableCell>{project.responseCount}</TableCell>
                          <TableCell>{formatDate(project.createdAt)}</TableCell>
                          <TableCell>{formatDate(project.updatedAt)}</TableCell>
                          <TableCell align="right">
                            <IconButton 
                              size="small" 
                              component={Link}
                              to={`/admin/projects/${project.id}`}
                              title="View Project"
                            >
                              <VisibilityIcon fontSize="small" />
                            </IconButton>
                            
                            <IconButton 
                              size="small" 
                              component={Link}
                              to={`/admin/projects/${project.id}/edit`}
                              title="Edit Project"
                            >
                              <EditIcon fontSize="small" />
                            </IconButton>
                            
                            {project.status === 'completed' && (
                              <IconButton 
                                size="small" 
                                color="primary"
                                component={Link}
                                to={`/admin/projects/${project.id}/analysis`}
                                title="View Analysis"
                              >
                                <AssessmentIcon fontSize="small" />
                              </IconButton>
                            )}
                            
                            <IconButton 
                              size="small" 
                              color="error"
                              title="Delete Project"
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                          </TableCell>
                        </TableRow>
                      ))}
                    
                    {filteredProjects.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} align="center" sx={{ py: 3 }}>
                          <Typography variant="body1" color="text.secondary">
                            No projects found
                          </Typography>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
              
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={filteredProjects.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </>
          )}
        </Box>
      </Paper>
    </Container>
  );
};

export default ProjectsList;
