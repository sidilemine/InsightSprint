import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  TextField, 
  Button, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  FormHelperText,
  CircularProgress,
  Alert,
  Stepper,
  Step,
  StepLabel,
  Card,
  CardContent,
  Divider,
  Chip,
  List,
  ListItem,
  ListItemIcon,
  ListItemText
} from '@mui/material';
import { 
  Save as SaveIcon,
  Assessment as AssessmentIcon,
  Source as SourceIcon,
  Settings as SettingsIcon,
  Check as CheckIcon,
  InsightsOutlined as InsightsIcon
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';

const AnalysisCreate = () => {
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [projects, setProjects] = useState([]);
  const [interviews, setInterviews] = useState([]);
  const [responses, setResponses] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [selectedSourceType, setSelectedSourceType] = useState('');
  const [selectedSourceId, setSelectedSourceId] = useState('');
  const [analysisOptions, setAnalysisOptions] = useState({
    includeEmotionAnalysis: true,
    includeTextAnalysis: true,
    includeMixedAnalysis: true,
    generateRecommendations: true,
    detectionThreshold: 0.5
  });
  const [previewData, setPreviewData] = useState(null);

  const steps = ['Select Project', 'Choose Source', 'Configure Analysis', 'Review & Create'];

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        // In a real implementation, this would fetch data from the API
        // For now, we'll use mock data
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Mock data
        const mockProjects = [
          {
            id: 'project-1',
            name: 'Beverage Product Testing',
            description: 'Consumer testing for new beverage product line',
            status: 'active'
          },
          {
            id: 'project-2',
            name: 'Snack Packaging Feedback',
            description: 'Consumer feedback on new packaging designs',
            status: 'active'
          },
          {
            id: 'project-3',
            name: 'Brand Perception Study',
            description: 'Analysis of consumer perception of brand values',
            status: 'active'
          }
        ];
        
        setProjects(mockProjects);
      } catch (err) {
        setError('Failed to load projects. Please try again.');
      }
    };
    
    fetchProjects();
  }, []);

  useEffect(() => {
    const fetchSources = async () => {
      if (!selectedProject || !selectedSourceType) return;
      
      try {
        setLoading(true);
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 700));
        
        // Mock data based on selected project and source type
        if (selectedSourceType === 'interview') {
          const mockInterviews = [
            {
              id: 'interview-1',
              projectId: 'project-1',
              participantId: 'part-101',
              status: 'completed',
              completedAt: '2025-04-12T10:30:00Z',
              title: 'Interview with Participant 101'
            },
            {
              id: 'interview-2',
              projectId: 'project-1',
              participantId: 'part-102',
              status: 'completed',
              completedAt: '2025-04-12T13:45:00Z',
              title: 'Interview with Participant 102'
            },
            {
              id: 'interview-3',
              projectId: 'project-2',
              participantId: 'part-201',
              status: 'completed',
              completedAt: '2025-04-13T09:15:00Z',
              title: 'Interview with Participant 201'
            }
          ];
          
          // Filter by selected project
          const filteredInterviews = mockInterviews.filter(interview => interview.projectId === selectedProject);
          setInterviews(filteredInterviews);
        } else if (selectedSourceType === 'response') {
          const mockResponses = [
            {
              id: 'resp-1',
              projectId: 'project-1',
              interviewId: 'interview-1',
              participantId: 'part-101',
              questionId: 1,
              questionText: 'What are your first impressions of this new beverage concept?',
              status: 'completed',
              title: 'Response to First Impressions Question (Participant 101)'
            },
            {
              id: 'resp-2',
              projectId: 'project-1',
              interviewId: 'interview-1',
              participantId: 'part-101',
              questionId: 2,
              questionText: 'How would you rate the appeal of the packaging design on a scale of 1-5?',
              status: 'completed',
              title: 'Response to Packaging Appeal Question (Participant 101)'
            },
            {
              id: 'resp-4',
              projectId: 'project-1',
              interviewId: 'interview-2',
              participantId: 'part-102',
              questionId: 1,
              questionText: 'What are your first impressions of this new beverage concept?',
              status: 'completed',
              title: 'Response to First Impressions Question (Participant 102)'
            },
            {
              id: 'resp-5',
              projectId: 'project-2',
              interviewId: 'interview-3',
              participantId: 'part-201',
              questionId: 1,
              questionText: 'What do you think about the new packaging design?',
              status: 'completed',
              title: 'Response to Packaging Design Question (Participant 201)'
            }
          ];
          
          // Filter by selected project
          const filteredResponses = mockResponses.filter(response => response.projectId === selectedProject);
          setResponses(filteredResponses);
        }
        
        setLoading(false);
      } catch (err) {
        setError('Failed to load sources. Please try again.');
        setLoading(false);
      }
    };
    
    fetchSources();
  }, [selectedProject, selectedSourceType]);

  useEffect(() => {
    // Generate preview data when all selections are made
    if (activeStep === 3 && selectedProject && selectedSourceType && selectedSourceId) {
      generatePreview();
    }
  }, [activeStep, selectedProject, selectedSourceType, selectedSourceId, analysisOptions]);

  const generatePreview = async () => {
    try {
      setLoading(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Get project name
      const project = projects.find(p => p.id === selectedProject);
      
      // Get source name
      let sourceName = '';
      if (selectedSourceType === 'interview') {
        const interview = interviews.find(i => i.id === selectedSourceId);
        sourceName = interview ? interview.title : '';
      } else if (selectedSourceType === 'response') {
        const response = responses.find(r => r.id === selectedSourceId);
        sourceName = response ? response.title : '';
      } else if (selectedSourceType === 'project') {
        sourceName = `${project.name} - Aggregate Analysis`;
      }
      
      // Mock preview data
      const mockPreview = {
        projectName: project ? project.name : '',
        sourceType: selectedSourceType,
        sourceName: sourceName,
        estimatedDuration: selectedSourceType === 'project' ? '3-5 minutes' : '1-2 minutes',
        analysisComponents: [],
        sampleInsights: []
      };
      
      // Add analysis components based on options
      if (analysisOptions.includeEmotionAnalysis) {
        mockPreview.analysisComponents.push('Voice Emotion Analysis');
      }
      
      if (analysisOptions.includeTextAnalysis) {
        mockPreview.analysisComponents.push('Text Sentiment Analysis');
      }
      
      if (analysisOptions.includeMixedAnalysis) {
        mockPreview.analysisComponents.push('Mixed Voice-Text Analysis');
      }
      
      if (analysisOptions.generateRecommendations) {
        mockPreview.analysisComponents.push('Strategic Recommendations');
      }
      
      // Add sample insights based on source type
      if (selectedSourceType === 'interview') {
        mockPreview.sampleInsights = [
          "Voice emotion patterns will be analyzed across all responses",
          "Text sentiment will be evaluated for consistency and authenticity",
          "Correlation between voice emotion and text content will reveal deeper insights",
          "Strategic recommendations will be generated based on the combined analysis"
        ];
      } else if (selectedSourceType === 'response') {
        mockPreview.sampleInsights = [
          "Detailed emotion analysis of voice patterns in this specific response",
          "In-depth text analysis to identify key themes and sentiments",
          "Comparison of stated opinions versus emotional reactions",
          "Specific recommendations based on this response"
        ];
      } else if (selectedSourceType === 'project') {
        mockPreview.sampleInsights = [
          "Aggregate analysis of all interviews and responses in the project",
          "Identification of common emotional patterns across participants",
          "Synthesis of key themes and sentiments from all text responses",
          "Strategic recommendations based on the entire project dataset"
        ];
      }
      
      setPreviewData(mockPreview);
      setLoading(false);
    } catch (err) {
      setError('Failed to generate preview. Please try again.');
      setLoading(false);
    }
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleProjectChange = (event) => {
    setSelectedProject(event.target.value);
    setSelectedSourceId(''); // Reset source selection when project changes
  };

  const handleSourceTypeChange = (event) => {
    setSelectedSourceType(event.target.value);
    setSelectedSourceId(''); // Reset source ID when type changes
  };

  const handleSourceIdChange = (event) => {
    setSelectedSourceId(event.target.value);
  };

  const handleAnalysisOptionChange = (option, value) => {
    setAnalysisOptions(prev => ({
      ...prev,
      [option]: value
    }));
  };

  const handleCreateAnalysis = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Mock successful creation
      setSuccess(true);
      setLoading(false);
      
      // Redirect to the analysis list after a short delay
      setTimeout(() => {
        navigate('/admin/analyses');
      }, 2000);
    } catch (err) {
      setError('Failed to create analysis. Please try again.');
      setLoading(false);
    }
  };

  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return renderProjectSelection();
      case 1:
        return renderSourceSelection();
      case 2:
        return renderAnalysisConfiguration();
      case 3:
        return renderReview();
      default:
        return null;
    }
  };

  const renderProjectSelection = () => {
    return (
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Select Project
        </Typography>
        
        <Typography variant="body2" color="text.secondary" paragraph>
          Choose the project for which you want to create an analysis.
        </Typography>
        
        <FormControl fullWidth sx={{ mt: 2 }}>
          <InputLabel id="project-select-label">Project</InputLabel>
          <Select
            labelId="project-select-label"
            id="project-select"
            value={selectedProject}
            label="Project"
            onChange={handleProjectChange}
          >
            {projects.map((project) => (
              <MenuItem key={project.id} value={project.id}>
                {project.name}
              </MenuItem>
            ))}
          </Select>
          <FormHelperText>Select a project to analyze</FormHelperText>
        </FormControl>
        
        <Box display="flex" justifyContent="flex-end" mt={3}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
            disabled={!selectedProject}
          >
            Next
          </Button>
        </Box>
      </Paper>
    );
  };

  const renderSourceSelection = () => {
    return (
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Choose Analysis Source
        </Typography>
        
        <Typography variant="body2" color="text.secondary" paragraph>
          Select the type of analysis you want to perform and the specific source.
        </Typography>
        
        <FormControl fullWidth sx={{ mt: 2, mb: 2 }}>
          <InputLabel id="source-type-select-label">Analysis Type</InputLabel>
          <Select
            labelId="source-type-select-label"
            id="source-type-select"
            value={selectedSourceType}
            label="Analysis Type"
            onChange={handleSourceTypeChange}
          >
            <MenuItem value="interview">Interview Analysis</MenuItem>
            <MenuItem value="response">Response Analysis</MenuItem>
            <MenuItem value="project">Project Analysis</MenuItem>
          </Select>
          <FormHelperText>Select the type of analysis to perform</FormHelperText>
        </FormControl>
        
        {selectedSourceType && selectedSourceType !== 'project' && (
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel id="source-select-label">
              {selectedSourceType === 'interview' ? 'Interview' : 'Response'}
            </InputLabel>
            <Select
              labelId="source-select-label"
              id="source-select"
              value={selectedSourceId}
              label={selectedSourceType === 'interview' ? 'Interview' : 'Response'}
              onChange={handleSourceIdChange}
              disabled={loading}
            >
              {selectedSourceType === 'interview' ? (
                interviews.map((interview) => (
                  <MenuItem key={interview.id} value={interview.id}>
                    {interview.title}
                  </MenuItem>
                ))
              ) : (
                responses.map((response) => (
                  <MenuItem key={response.id} value={response.id}>
                    {response.title}
                  </MenuItem>
                ))
              )}
            </Select>
            <FormHelperText>
              {selectedSourceType === 'interview' 
                ? 'Select the interview to analyze' 
                : 'Select the response to analyze'}
            </FormHelperText>
          </FormControl>
        )}
        
        {selectedSourceType === 'project' && (
          <Alert severity="info" sx={{ mt: 2 }}>
            Project analysis will analyze all interviews and responses in the selected project.
            This may take longer to process than individual analyses.
          </Alert>
        )}
        
        <Box display="flex" justifyContent="space-between" mt={3}>
          <Button
            variant="outlined"
            onClick={handleBack}
          >
            Back
          </Button>
          
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
            disabled={!selectedSourceType || (selectedSourceType !== 'project' && !selectedSourceId)}
          >
            Next
          </Button>
        </Box>
      </Paper>
    );
  };

  const renderAnalysisConfiguration = () => {
    return (
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Configure Analysis
        </Typography>
        
        <Typography variant="body2" color="text.secondary" paragraph>
          Customize the analysis settings to meet your specific needs.
        </Typography>
        
        <Grid container spacing={3} sx={{ mt: 1 }}>
          <Grid item xs={12}>
            <FormControl component="fieldset">
              <Typography variant="subtitle1" gutterBottom>
                Analysis Components
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={analysisOptions.includeEmotionAnalysis}
                        onChange={(e) => handleAnalysisOptionChange('includeEmotionAnalysis', e.target.checked)}
                        color="primary"
                      />
                    }
                    label="Include Voice Emotion Analysis"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={analysisOptions.includeTextAnalysis}
                        onChange={(e) => handleAnalysisOptionChange('includeTextAnalysis', e.target.checked)}
                        color="primary"
                      />
                    }
                    label="Include Text Sentiment Analysis"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={analysisOptions.includeMixedAnalysis}
                        onChange={(e) => handleAnalysisOptionChange('includeMixedAnalysis', e.target.checked)}
                        color="primary"
                      />
                    }
                    label="Include Mixed Voice-Text Analysis"
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={analysisOptions.generateRecommendations}
                        onChange={(e) => handleAnalysisOptionChange('generateRecommendations', e.target.checked)}
                        color="primary"
                      />
                    }
                    label="Generate Strategic Recommendations"
                  />
                </Grid>
              </Grid>
            </FormControl>
          </Grid>
          
          <Grid item xs={12}>
            <Typography variant="subtitle1" gutterBottom>
              Detection Sensitivity
            </Typography>
            
            <Typography variant="body2" color="text.secondary" gutterBottom>
              Adjust the threshold for emotion and sentiment detection (higher values require stronger signals)
            </Typography>
            
            <Slider
              value={analysisOptions.detectionThreshold}
              onChange={(e, newValue) => handleAnalysisOptionChange('detectionThreshold', newValue)}
              aria-labelledby="detection-threshold-slider"
              valueLabelDisplay="auto"
              step={0.1}
              marks
              min={0.1}
              max={0.9}
              sx={{ maxWidth: 400 }}
            />
            
            <Box display="flex" justifyContent="space-between" maxWidth={400}>
              <Typography variant="caption" color="text.secondary">
                More Sensitive
              </Typography>
              <Typography variant="caption" color="text.secondary">
                More Selective
              </Typography>
            </Box>
          </Grid>
        </Grid>
        
        <Box display="flex" justifyContent="space-between" mt={3}>
          <Button
            variant="outlined"
            onClick={handleBack}
          >
            Back
          </Button>
          
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
            disabled={!analysisOptions.includeEmotionAnalysis && !analysisOptions.includeTextAnalysis && !analysisOptions.includeMixedAnalysis}
          >
            Next
          </Button>
        </Box>
      </Paper>
    );
  };

  // Define FormControlLabel and Checkbox components for use in the component
  const FormControlLabel = ({ control, label }) => {
    return (
      <Box display="flex" alignItems="center" mb={1}>
        {React.cloneElement(control, { size: 'medium' })}
        <Typography variant="body1" sx={{ ml: 1 }}>
          {label}
        </Typography>
      </Box>
    );
  };

  const Checkbox = ({ checked, onChange, color }) => {
    return (
      <Box
        component="span"
        sx={{
          display: 'inline-block',
          width: 24,
          height: 24,
          borderRadius: 1,
          border: '2px solid',
          borderColor: checked ? `${color}.main` : 'text.disabled',
          bgcolor: checked ? `${color}.main` : 'transparent',
          position: 'relative',
          cursor: 'pointer',
        }}
        onClick={() => onChange({ target: { checked: !checked } })}
      >
        {checked && (
          <CheckIcon
            fontSize="small"
            sx={{
              color: 'white',
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
            }}
          />
        )}
      </Box>
    );
  };

  // Define Slider component for use in the component
  const Slider = ({ value, onChange, min, max, step, marks, valueLabelDisplay, sx }) => {
    const handleClick = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const offsetX = e.clientX - rect.left;
      const percentage = offsetX / rect.width;
      const newValue = min + percentage * (max - min);
      const steppedValue = Math.round(newValue / step) * step;
      const clampedValue = Math.max(min, Math.min(max, steppedValue));
      onChange(null, clampedValue);
    };

    return (
      <Box sx={{ ...sx, position: 'relative', height: 8, bgcolor: 'background.paper', borderRadius: 4, mb: 2 }} onClick={handleClick}>
        <Box
          sx={{
            position: 'absolute',
            height: '100%',
            width: `${((value - min) / (max - min)) * 100}%`,
            bgcolor: 'primary.main',
            borderRadius: 4,
          }}
        />
        <Box
          sx={{
            position: 'absolute',
            height: 16,
            width: 16,
            bgcolor: 'primary.main',
            borderRadius: '50%',
            top: '50%',
            left: `${((value - min) / (max - min)) * 100}%`,
            transform: 'translate(-50%, -50%)',
            boxShadow: 2,
          }}
        />
        {valueLabelDisplay === 'auto' && (
          <Typography
            variant="caption"
            sx={{
              position: 'absolute',
              top: -24,
              left: `${((value - min) / (max - min)) * 100}%`,
              transform: 'translateX(-50%)',
              bgcolor: 'primary.main',
              color: 'white',
              px: 1,
              py: 0.5,
              borderRadius: 1,
            }}
          >
            {value.toFixed(1)}
          </Typography>
        )}
        {marks && (
          <Box sx={{ position: 'relative', width: '100%', height: '100%' }}>
            {Array.from({ length: Math.floor((max - min) / step) + 1 }).map((_, index) => (
              <Box
                key={index}
                sx={{
                  position: 'absolute',
                  height: 4,
                  width: 1,
                  bgcolor: 'text.disabled',
                  top: '50%',
                  left: `${(index * step) / (max - min) * 100}%`,
                  transform: 'translateY(-50%)',
                }}
              />
            ))}
          </Box>
        )}
      </Box>
    );
  };

  const renderReview = () => {
    if (loading) {
      return (
        <Box display="flex" justifyContent="center" my={5}>
          <CircularProgress />
        </Box>
      );
    }
    
    if (!previewData) {
      return (
        <Alert severity="error">
          Failed to generate preview. Please go back and try again.
        </Alert>
      );
    }
    
    return (
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Review & Create Analysis
        </Typography>
        
        <Typography variant="body2" color="text.secondary" paragraph>
          Review your analysis configuration and create the analysis.
        </Typography>
        
        <Grid container spacing={3} sx={{ mt: 1 }}>
          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="subtitle1" color="primary" gutterBottom>
                  Analysis Details
                </Typography>
                
                <Box mb={2}>
                  <Typography variant="body2" color="text.secondary">
                    Project
                  </Typography>
                  <Typography variant="body1">
                    {previewData.projectName}
                  </Typography>
                </Box>
                
                <Box mb={2}>
                  <Typography variant="body2" color="text.secondary">
                    Analysis Type
                  </Typography>
                  <Typography variant="body1">
                    {selectedSourceType === 'interview' 
                      ? 'Interview Analysis' 
                      : selectedSourceType === 'response'
                        ? 'Response Analysis'
                        : 'Project Analysis'}
                  </Typography>
                </Box>
                
                <Box mb={2}>
                  <Typography variant="body2" color="text.secondary">
                    Source
                  </Typography>
                  <Typography variant="body1">
                    {previewData.sourceName}
                  </Typography>
                </Box>
                
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Estimated Processing Time
                  </Typography>
                  <Typography variant="body1">
                    {previewData.estimatedDuration}
                  </Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Card variant="outlined">
              <CardContent>
                <Typography variant="subtitle1" color="primary" gutterBottom>
                  Analysis Components
                </Typography>
                
                <Box display="flex" flexWrap="wrap" gap={1} mb={3}>
                  {previewData.analysisComponents.map((component, index) => (
                    <Chip 
                      key={index}
                      label={component} 
                      color="primary"
                      variant="outlined"
                    />
                  ))}
                </Box>
                
                <Typography variant="subtitle1" color="primary" gutterBottom>
                  Sample Insights
                </Typography>
                
                <List>
                  {previewData.sampleInsights.map((insight, index) => (
                    <ListItem key={index} alignItems="flex-start" disableGutters>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <InsightsIcon color="primary" fontSize="small" />
                      </ListItemIcon>
                      <ListItemText primary={insight} />
                    </ListItem>
                  ))}
                </List>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        
        <Box display="flex" justifyContent="space-between" mt={3}>
          <Button
            variant="outlined"
            onClick={handleBack}
          >
            Back
          </Button>
          
          <Button
            variant="contained"
            color="primary"
            startIcon={<AssessmentIcon />}
            onClick={handleCreateAnalysis}
            disabled={loading || success}
          >
            Create Analysis
          </Button>
        </Box>
        
        {success && (
          <Alert severity="success" sx={{ mt: 3 }}>
            Analysis created successfully! Redirecting to analysis list...
          </Alert>
        )}
      </Paper>
    );
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Create New Analysis
        </Typography>
      </Box>
      
      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}
      
      <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      
      {renderStepContent(activeStep)}
    </Container>
  );
};

export default AnalysisCreate;
