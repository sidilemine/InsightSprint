import React, { useState, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Box, 
  Paper, 
  Grid, 
  Button, 
  Chip, 
  Divider, 
  Tabs, 
  Tab, 
  CircularProgress,
  Alert,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  ListItemIcon
} from '@mui/material';
import { 
  Edit as EditIcon,
  Assessment as AssessmentIcon,
  Send as SendIcon,
  QuestionAnswer as QuestionAnswerIcon,
  InsightsOutlined as InsightsIcon,
  RecordVoiceOver as RecordVoiceOverIcon,
  SentimentSatisfiedAlt as SentimentIcon,
  TextFields as TextFieldsIcon
} from '@mui/icons-material';
import { useParams, Link } from 'react-router-dom';

const InterviewDetail = () => {
  const { interviewId } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [interview, setInterview] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  
  useEffect(() => {
    const fetchInterviewDetails = async () => {
      try {
        setLoading(true);
        setError('');
        
        // In a real implementation, this would fetch data from the API
        // For now, we'll use mock data
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Mock data
        const mockInterview = {
          id: interviewId,
          projectId: 'project-1',
          projectName: 'Beverage Product Testing',
          participantId: 'part-101',
          status: 'completed',
          duration: 420, // seconds
          completedAt: '2025-04-12T10:15:00Z',
          questions: [
            {
              id: 1,
              text: 'What are your first impressions of this new beverage concept?',
              type: 'open_ended',
              response: {
                text: "I'm intrigued by the natural ingredients and the sustainable packaging. The colors are vibrant and appealing. It looks refreshing and I'd be curious to try it.",
                audioUrl: '/audio/response-1.mp3',
                duration: 28, // seconds
                emotionAnalysis: {
                  primary: 'Interest',
                  secondary: 'Joy',
                  emotions: [
                    { name: 'Interest', score: 0.72 },
                    { name: 'Joy', score: 0.45 },
                    { name: 'Surprise', score: 0.23 },
                    { name: 'Skepticism', score: 0.12 },
                    { name: 'Confusion', score: 0.08 }
                  ]
                },
                textAnalysis: {
                  sentiment: 'positive',
                  score: 0.78,
                  keywords: ['natural ingredients', 'sustainable packaging', 'vibrant', 'appealing', 'refreshing'],
                  themes: ['Product Appearance', 'Sustainability', 'Natural Ingredients']
                }
              }
            },
            {
              id: 2,
              text: 'How would you rate the appeal of the packaging design on a scale of 1-5?',
              type: 'scale',
              response: {
                value: 4,
                audioUrl: '/audio/response-2.mp3',
                duration: 15, // seconds
                emotionAnalysis: {
                  primary: 'Satisfaction',
                  secondary: 'Interest',
                  emotions: [
                    { name: 'Satisfaction', score: 0.68 },
                    { name: 'Interest', score: 0.52 },
                    { name: 'Joy', score: 0.31 },
                    { name: 'Surprise', score: 0.15 },
                    { name: 'Skepticism', score: 0.05 }
                  ]
                },
                textAnalysis: {
                  sentiment: 'positive',
                  score: 0.82,
                  keywords: ['design', 'appealing', 'modern'],
                  themes: ['Packaging Design', 'Visual Appeal']
                }
              }
            },
            {
              id: 3,
              text: 'What emotions do you feel when you think about trying this product?',
              type: 'open_ended',
              response: {
                text: "I feel curious and excited to try something new. There's also a bit of anticipation about the taste. I'm hopeful it will be refreshing and flavorful without being too sweet like many other beverages.",
                audioUrl: '/audio/response-3.mp3',
                duration: 32, // seconds
                emotionAnalysis: {
                  primary: 'Anticipation',
                  secondary: 'Curiosity',
                  emotions: [
                    { name: 'Anticipation', score: 0.81 },
                    { name: 'Curiosity', score: 0.75 },
                    { name: 'Joy', score: 0.42 },
                    { name: 'Hope', score: 0.38 },
                    { name: 'Concern', score: 0.12 }
                  ]
                },
                textAnalysis: {
                  sentiment: 'positive',
                  score: 0.71,
                  keywords: ['curious', 'excited', 'anticipation', 'refreshing', 'flavorful', 'not too sweet'],
                  themes: ['Taste Expectations', 'Novelty', 'Flavor Profile']
                }
              }
            },
            {
              id: 4,
              text: 'Would you consider purchasing this product when it becomes available?',
              type: 'yes_no',
              response: {
                value: 'yes',
                audioUrl: '/audio/response-4.mp3',
                duration: 18, // seconds
                emotionAnalysis: {
                  primary: 'Interest',
                  secondary: 'Anticipation',
                  emotions: [
                    { name: 'Interest', score: 0.65 },
                    { name: 'Anticipation', score: 0.58 },
                    { name: 'Joy', score: 0.32 },
                    { name: 'Uncertainty', score: 0.15 },
                    { name: 'Skepticism', score: 0.10 }
                  ]
                },
                textAnalysis: {
                  sentiment: 'positive',
                  score: 0.85,
                  keywords: ['purchase', 'try', 'available'],
                  themes: ['Purchase Intent', 'Product Trial']
                }
              }
            },
            {
              id: 5,
              text: 'What improvements would you suggest for this product?',
              type: 'open_ended',
              response: {
                text: "I'd like to see more information about the sourcing of ingredients and perhaps some details about the nutritional benefits. Also, it would be great if the packaging was 100% recyclable or compostable. I'm also curious about the price point - if it's too premium, it might be a barrier to regular purchase.",
                audioUrl: '/audio/response-5.mp3',
                duration: 42, // seconds
                emotionAnalysis: {
                  primary: 'Thoughtfulness',
                  secondary: 'Concern',
                  emotions: [
                    { name: 'Thoughtfulness', score: 0.78 },
                    { name: 'Concern', score: 0.45 },
                    { name: 'Interest', score: 0.38 },
                    { name: 'Skepticism', score: 0.25 },
                    { name: 'Hope', score: 0.20 }
                  ]
                },
                textAnalysis: {
                  sentiment: 'neutral',
                  score: 0.52,
                  keywords: ['sourcing', 'nutritional benefits', 'recyclable', 'compostable', 'price point', 'premium', 'barrier'],
                  themes: ['Transparency', 'Sustainability', 'Pricing Concerns', 'Nutritional Information']
                }
              }
            }
          ],
          emotionSummary: {
            primary: 'Interest',
            secondary: 'Anticipation',
            overall: [
              { name: 'Interest', score: 0.68 },
              { name: 'Anticipation', score: 0.59 },
              { name: 'Joy', score: 0.42 },
              { name: 'Curiosity', score: 0.38 },
              { name: 'Satisfaction', score: 0.34 },
              { name: 'Concern', score: 0.21 },
              { name: 'Skepticism', score: 0.13 }
            ]
          },
          textSummary: {
            sentiment: 'positive',
            score: 0.74,
            keyThemes: [
              'Product Appearance',
              'Sustainability',
              'Taste Expectations',
              'Packaging Design',
              'Pricing Concerns',
              'Transparency'
            ]
          },
          mixedAnalysis: {
            insights: [
              "The participant shows genuine interest and anticipation about the product, with voice emotion analysis confirming the positive sentiment expressed in their words.",
              "While verbally expressing excitement about the sustainable packaging, their voice revealed underlying concern, suggesting deeper environmental values.",
              "The participant's voice showed higher enthusiasm when discussing natural ingredients than their text alone would suggest.",
              "Price sensitivity was detected in both voice emotion and text analysis, indicating this could be a key decision factor.",
              "The emotional response was strongest when discussing product appearance and taste expectations, suggesting these are the most important product attributes for this consumer."
            ],
            recommendations: [
              "Emphasize natural ingredients and sustainability in marketing materials to align with the participant's strongest positive emotional responses.",
              "Consider addressing price concerns directly in messaging to overcome the detected hesitation.",
              "Highlight nutritional benefits as this generated interest but also revealed information gaps.",
              "The packaging design received positive emotional responses and should be maintained in the final product."
            ]
          }
        };
        
        setInterview(mockInterview);
        setLoading(false);
      } catch (err) {
        setError('Failed to load interview details. Please try again.');
        setLoading(false);
      }
    };
    
    fetchInterviewDetails();
  }, [interviewId]);
  
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  const formatDuration = (seconds) => {
    if (!seconds) return 'N/A';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'success';
      case 'in_progress':
        return 'warning';
      case 'scheduled':
        return 'info';
      case 'cancelled':
        return 'error';
      default:
        return 'default';
    }
  };
  
  const getSentimentColor = (sentiment) => {
    switch (sentiment) {
      case 'positive':
        return 'success';
      case 'neutral':
        return 'info';
      case 'negative':
        return 'error';
      default:
        return 'default';
    }
  };
  
  const renderOverviewTab = () => {
    return (
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
              Interview Details
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Project
                </Typography>
                <Typography variant="body1" paragraph>
                  {interview.projectName}
                </Typography>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Participant ID
                </Typography>
                <Typography variant="body1" paragraph>
                  {interview.participantId}
                </Typography>
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Status
                </Typography>
                <Chip 
                  label={interview.status.charAt(0).toUpperCase() + interview.status.slice(1)} 
                  color={getStatusColor(interview.status)}
                  size="small"
                />
              </Grid>
              
              <Grid item xs={12} md={6}>
                <Typography variant="subtitle2" color="text.secondary">
                  Duration
                </Typography>
                <Typography variant="body1">
                  {formatDuration(interview.duration)}
                </Typography>
              </Grid>
              
              <Grid item xs={12}>
                <Typography variant="subtitle2" color="text.secondary">
                  Completed At
                </Typography>
                <Typography variant="body1">
                  {formatDate(interview.completedAt)}
                </Typography>
              </Grid>
            </Grid>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">
                Emotion Summary
              </Typography>
              
              <Chip 
                icon={<SentimentIcon />}
                label={`Primary: ${interview.emotionSummary.primary}`} 
                color="primary"
              />
            </Box>
            
            <Typography variant="body2" color="text.secondary" paragraph>
              Overall emotional response detected across all interview questions
            </Typography>
            
            <List>
              {interview.emotionSummary.overall.map((emotion) => (
                <ListItem key={emotion.name} disableGutters>
                  <ListItemText 
                    primary={
                      <Box display="flex" alignItems="center">
                        <Typography variant="body1" sx={{ minWidth: 100 }}>
                          {emotion.name}
                        </Typography>
                        <Box width="100%" mr={1} ml={2}>
                          <LinearProgress 
                            variant="determinate" 
                            value={emotion.score * 100} 
                            sx={{ height: 10, borderRadius: 5 }} 
                          />
                        </Box>
                        <Typography variant="body2" color="text.secondary">
                          {Math.round(emotion.score * 100)}%
                        </Typography>
                      </Box>
                    }
                  />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
              <Typography variant="h6">
                Text Analysis
              </Typography>
              
              <Chip 
                label={interview.textSummary.sentiment.charAt(0).toUpperCase() + interview.textSummary.sentiment.slice(1)} 
                color={getSentimentColor(interview.textSummary.sentiment)}
                size="small"
              />
            </Box>
            
            <Typography variant="body2" color="text.secondary" paragraph>
              Overall sentiment score: {Math.round(interview.textSummary.score * 100)}%
            </Typography>
            
            <Typography variant="subtitle2" color="text.secondary" sx={{ mt: 2 }}>
              Key Themes
            </Typography>
            
            <Box display="flex" flexWrap="wrap" gap={1} mt={1}>
              {interview.textSummary.keyThemes.map((theme) => (
                <Chip 
                  key={theme}
                  label={theme}
                  size="small"
                  variant="outlined"
                />
              ))}
            </Box>
          </Paper>
          
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Actions
            </Typography>
            
            <Button
              fullWidth
              variant="contained"
              color="primary"
              startIcon={<AssessmentIcon />}
              component={Link}
              to={`/admin/interviews/${interview.id}/analysis`}
              sx={{ mb: 2 }}
            >
              View Full Analysis
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              startIcon={<EditIcon />}
              component={Link}
              to={`/admin/interviews/${interview.id}/edit`}
              sx={{ mb: 2 }}
            >
              Edit Notes
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              color="secondary"
              startIcon={<SendIcon />}
              component={Link}
              to={`/admin/interviews/${interview.id}/share`}
            >
              Share Results
            </Button>
          </Paper>
        </Grid>
      </Grid>
    );
  };
  
  const renderQuestionsTab = () => {
    return (
      <Grid container spacing={3}>
        {interview.questions.map((question, index) => (
          <Grid item xs={12} key={question.id}>
            <Paper sx={{ p: 3, mb: index < interview.questions.length - 1 ? 3 : 0 }}>
              <Box display="flex" alignItems="center" mb={2}>
                <QuestionAnswerIcon color="primary" sx={{ mr: 1 }} />
                <Typography variant="h6">
                  Question {index + 1}: {question.text}
                </Typography>
              </Box>
              
              <Typography variant="body2" color="text.secondary" mb={2}>
                Type: {question.type.replace('_', ' ').charAt(0).toUpperCase() + question.type.replace('_', ' ').slice(1)}
              </Typography>
              
              <Divider sx={{ my: 2 }} />
              
              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Card variant="outlined">
                    <CardContent>
                      <Box display="flex" alignItems="center" mb={2}>
                        <RecordVoiceOverIcon color="primary" sx={{ mr: 1 }} />
                        <Typography variant="subtitle1">
                          Voice Response
                        </Typography>
                      </Box>
                      
                      <Box mb={2}>
                        <audio 
                          controls 
                          src={question.response.audioUrl}
                          style={{ width: '100%' }}
                        >
                          Your browser does not support the audio element.
                        </audio>
                        <Typography variant="body2" color="text.secondary" align="right">
                          Duration: {formatDuration(question.response.duration)}
                        </Typography>
                      </Box>
                      
                      <Typography variant="subtitle2" color="text.secondary">
                        Emotion Analysis
                      </Typography>
                      
                      <Box display="flex" gap={1} mt={1} mb={2}>
                        <Chip 
                          label={`Primary: ${question.response.emotionAnalysis.primary}`} 
                          size="small" 
                          color="primary" 
                        />
                        <Chip 
                          label={`Secondary: ${question.response.emotionAnalysis.secondary}`} 
                          size="small" 
                          color="secondary" 
                        />
                      </Box>
                      
                      {question.response.emotionAnalysis.emotions.map((emotion) => (
                        <Box key={emotion.name} display="flex" alignItems="center" mb={1}>
                          <Typography variant="body2" sx={{ minWidth: 100 }}>
                            {emotion.name}
                          </Typography>
                          <Box width="100%" mr={1} ml={1}>
                            <LinearProgress 
                              variant="determinate" 
                              value={emotion.score * 100} 
                              sx={{ height: 8, borderRadius: 4 }} 
                            />
                          </Box>
                          <Typography variant="body2" color="text.secondary">
                            {Math.round(emotion.score * 100)}%
                          </Typography>
                        </Box>
                      ))}
                    </CardContent>
                  </Card>
                </Grid>
                
                <Grid item xs={12} md={6}>
                  <Card variant="outlined">
                    <CardContent>
                      <Box display="flex" alignItems="center" mb={2}>
                        <TextFieldsIcon color="primary" sx={{ mr: 1 }} />
                        <Typography variant="subtitle1">
                          Text Response
                        </Typography>
                      </Box>
                      
                      {question.type === 'open_ended' ? (
                        <Typography variant="body1" paragraph>
                          "{question.response.text}"
                        </Typography>
                      ) : question.type === 'scale' ? (
                        <Typography variant="body1" paragraph>
                          Rating: <strong>{question.response.value}/5</strong>
                        </Typography>
                      ) : question.type === 'yes_no' ? (
                        <Typography variant="body1" paragraph>
                          Answer: <strong>{question.response.value.charAt(0).toUpperCase() + question.response.value.slice(1)}</strong>
                        </Typography>
                      ) : (
                        <Typography variant="body1" paragraph>
                          {question.response.text || question.response.value}
                        </Typography>
                      )}
                      
                      <Typography variant="subtitle2" color="text.secondary">
                        Text Analysis
                      </Typography>
                      
                      <Box display="flex" alignItems="center" mt={1} mb={2}>
                        <Typography variant="body2" sx={{ mr: 1 }}>
                          Sentiment:
                        </Typography>
                        <Chip 
                          label={question.response.textAnalysis.sentiment.charAt(0).toUpperCase() + question.response.textAnalysis.sentiment.slice(1)} 
                          size="small"
                          color={getSentimentColor(question.response.textAnalysis.sentiment)}
                        />
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                          Score: {Math.round(question.response.textAnalysis.score * 100)}%
                        </Typography>
                      </Box>
                      
                      <Typography variant="body2" color="text.secondary">
                        Keywords:
                      </Typography>
                      
                      <Box display="flex" flexWrap="wrap" gap={0.5} mt={0.5} mb={2}>
                        {question.response.textAnalysis.keywords.map((keyword) => (
                          <Chip 
                            key={keyword}
                            label={keyword}
                            size="small"
                            variant="outlined"
                          />
                        ))}
                      </Box>
                      
                      <Typography variant="body2" color="text.secondary">
                        Themes:
                      </Typography>
                      
                      <Box display="flex" flexWrap="wrap" gap={0.5} mt={0.5}>
                        {question.response.textAnalysis.themes.map((theme) => (
                          <Chip 
                            key={theme}
                            label={theme}
                            size="small"
                            color="primary"
                            variant="outlined"
                          />
                        ))}
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        ))}
      </Grid>
    );
  };
  
  const renderMixedAnalysisTab = () => {
    return (
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper sx={{ p: 3, mb: 3 }}>
            <Box display="flex" alignItems="center" mb={3}>
              <InsightsIcon color="primary" sx={{ mr: 1, fontSize: 28 }} />
              <Typography variant="h5">
                Combined Voice & Text Insights
              </Typography>
            </Box>
            
            <Typography variant="body2" color="text.secondary" paragraph>
              These insights are generated by analyzing the correlation between voice emotion patterns and text content, revealing deeper understanding than either analysis alone.
            </Typography>
            
            <List>
              {interview.mixedAnalysis.insights.map((insight, index) => (
                <ListItem key={index} alignItems="flex-start">
                  <ListItemIcon sx={{ minWidth: 36 }}>
                    <InsightsIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText primary={insight} />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
        
        <Grid item xs={12}>
          <Paper sx={{ p: 3 }}>
            <Box display="flex" alignItems="center" mb={3}>
              <AssessmentIcon color="secondary" sx={{ mr: 1, fontSize: 28 }} />
              <Typography variant="h5">
                Recommendations
              </Typography>
            </Box>
            
            <Typography variant="body2" color="text.secondary" paragraph>
              Strategic recommendations based on the combined analysis of voice emotions and text content.
            </Typography>
            
            <List>
              {interview.mixedAnalysis.recommendations.map((recommendation, index) => (
                <ListItem key={index} alignItems="flex-start">
                  <ListItemIcon sx={{ minWidth: 36 }}>
                    <AssessmentIcon color="secondary" />
                  </ListItemIcon>
                  <ListItemText primary={recommendation} />
                </ListItem>
              ))}
            </List>
          </Paper>
        </Grid>
      </Grid>
    );
  };
  
  // Define LinearProgress component for use in the component
  const LinearProgress = ({ variant, value, sx }) => {
    return (
      <Box sx={{ width: '100%', bgcolor: 'background.paper', borderRadius: sx?.borderRadius || 0, ...sx }}>
        <Box
          sx={{
            width: `${value}%`,
            height: sx?.height || 4,
            bgcolor: 'primary.main',
            borderRadius: sx?.borderRadius || 0,
          }}
        />
      </Box>
    );
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {loading ? (
        <Box display="flex" justifyContent="center" my={5}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      ) : interview ? (
        <>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
            <Typography variant="h4" component="h1">
              Interview Details
            </Typography>
            
            <Chip 
              label={interview.status.charAt(0).toUpperCase() + interview.status.slice(1)} 
              color={getStatusColor(interview.status)}
            />
          </Box>
          
          <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
            <Tabs value={tabValue} onChange={handleTabChange} aria-label="interview tabs">
              <Tab label="Overview" />
              <Tab label="Questions & Responses" />
              <Tab label="Mixed Analysis" />
            </Tabs>
          </Box>
          
          {tabValue === 0 && renderOverviewTab()}
          {tabValue === 1 && renderQuestionsTab()}
          {tabValue === 2 && renderMixedAnalysisTab()}
        </>
      ) : (
        <Alert severity="error">
          Interview not found
        </Alert>
      )}
    </Container>
  );
};

export default InterviewDetail;
