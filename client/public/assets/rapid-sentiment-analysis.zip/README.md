# Rapid Consumer Sentiment Analysis

A sophisticated service that combines AI-moderated mini-qual interviews with Voice Emotion Recognition technology to deliver fast, affordable insights for CPG brands.

## Features

- Voice Emotion Recognition using Hume AI
- Natural Language Processing with Gemini API
- Mixed emotion-language analysis for deeper insights
- Data storage with Airtable
- Visualization with Insight7
- Admin Dashboard, Client Portal, and Respondent Interface

## Getting Started

### Prerequisites

- Node.js 16+
- MongoDB
- API keys for external services (Voiceform, Hume AI, Gemini, Airtable, Insight7)

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   cd client
   npm install
   ```
3. Configure environment variables in `.env` file
4. Start the development server:
   ```
   npm run dev:full
   ```

### Testing

Run tests with:
```
npm test
```

## Deployment

To deploy the application:
```
npm run deploy
```

## License

This project is proprietary software owned by Jade Kite.

## Contact

For more information, contact Jade Kite.